# Excel en Python

_Una libreria para hacer mediciones estadísticas basicas de datos_

## Instalación
_Instalar el proyecto_
```
pip install excel-python
```

## Comenzando 🚀

_Estas instrucciones te permitirán obtener una copia del proyecto en funcionamiento en tu máquina local para propósitos de desarrollo y pruebas._

Mira **Deployment** para conocer como desplegar el proyecto.


### Pre-requisitos 📋

_clona el proyecto_

```
git clone https://github.com/PeraBaja/excel-python.git
```
_instala numpy_

```
pip install numpy
```
