from Agrupacion import Agrupacion
from Frecuencias import Frecuencias
from Intervalo import Intervalo
from MedicionesAgrupacion import MedicionesAgrupacion
from Muestra import Muestra